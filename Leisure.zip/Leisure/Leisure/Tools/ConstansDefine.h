//
//  ConstansDefine.h
//  Leisure
//
//  Created by 沈强 on 16/3/29.
//  Copyright © 2016年 SQ. All rights reserved.
//

#ifndef ConstansDefine_h
#define ConstansDefine_h

#pragma mark -屏幕尺寸-
/** 屏幕宽 */
#define ScreenWidth     [[UIScreen mainScreen] bounds].size.width
/** 屏幕高 */
#define ScreenHeight    [[UIScreen mainScreen] bounds].size.height
/** 导航条高度 */
#define NavigationBarHeight     44.0   

#pragma mark -颜色-


#endif /* ConstansDefine_h */
