//
//  RadioTableViewCell.h
//  Leisure
//
//  Created by 沈强 on 16/4/2.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioAlllistModel.h"

@interface RadioTableViewCell : UITableViewCell

@property (nonatomic, strong) RadioAlllistModel *model;

@end
