//
//  RadioInfoHeaderView.h
//  Leisure
//
//  Created by 沈强 on 16/4/2.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import "BaseView.h"
#import "RadioDetailInfoModel.h"

@interface RadioDetailHeaderView : BaseView

@property (nonatomic, strong) RadioDetailInfoModel *model;

@end
