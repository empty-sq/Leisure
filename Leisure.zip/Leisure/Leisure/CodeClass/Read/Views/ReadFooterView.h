//
//  ReadFooterView.h
//  Leisure
//
//  Created by 沈强 on 16/3/30.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReadFooterView : UICollectionReusableView

@property (nonatomic, strong) UIButton *imageButton;
@property (nonatomic, strong) UILabel *ennameLabel;
@property (nonatomic, strong) UILabel *nameLabel;

@end
