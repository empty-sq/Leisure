//
//  ReadListModel.m
//  Leisure
//
//  Created by 沈强 on 16/3/29.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import "ReadListModel.h"

@implementation ReadListModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
