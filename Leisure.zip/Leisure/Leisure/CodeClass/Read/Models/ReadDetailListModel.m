//
//  ReadDetailListModel.m
//  Leisure
//
//  Created by 沈强 on 16/3/29.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import "ReadDetailListModel.h"

@implementation ReadDetailListModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
