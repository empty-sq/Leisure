//
//  TopicListModel.m
//  Leisure
//
//  Created by 沈强 on 16/3/30.
//  Copyright © 2016年 SQ. All rights reserved.
//

#import "TopicListModel.h"

@implementation TopicListModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
